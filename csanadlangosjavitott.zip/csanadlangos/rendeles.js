const langosok = document.querySelectorAll("[data-langos]")
const button = document.querySelector("a")
let langosjson = []
let langos = {"nev": null, "ar": null, "darab": null, "so": null, "fokhagyma": null}

button.addEventListener("click", Tarol)

console.log(fasz)

function Tarol(){
    for (let i = 0; i < langosok.length; i++){
        let actualis_langos = langosok[i].children

        if (actualis_langos[11].value > 0 && actualis_langos[11].value != undefined){
            langos.nev = actualis_langos[0].innerHTML
            langos.ar = actualis_langos[4].innerHTML
            langos.darab = actualis_langos[11].value

            if (actualis_langos[8].checked){
                langos.so = "Só"

            } else{
                langos.so = null
            }
            
            if (actualis_langos[9].checked){
                langos.fokhagyma = "Fokhagyma"

            } else{
                langos.fokhagyma = null
            }

            if (actualis_langos[0].innerHTML == "Nutellás"){
                if (actualis_langos[8].checked){
                    langos.so = "Banán"
    
                } else{
                    langos.so = null
                }
                
                if (actualis_langos[9].checked){
                    langos.fokhagyma = "Tejszínhab"
    
                } else{
                    langos.fokhagyma = null
                }
            }

            

            let langos_vegleges = {...langos}
            langosjson.push(langos_vegleges)
        }
        
    }
    if (langosjson.length == 0){
        alert("Kérem, adja le a rendelést")
        
    } else{
        localStorage.setItem('atalakitottjson', JSON.stringify(langosjson));
        window.location.href = "osszegzes.html"
    }

}