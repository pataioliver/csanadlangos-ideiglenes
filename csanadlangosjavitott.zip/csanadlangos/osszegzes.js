const langosjson = JSON.parse(localStorage.getItem('atalakitottjson'));
const langosok = document.querySelector("[data-langosok]").children
const button = document.querySelector("button")
let langosnevek = []
let osszesen = 0

window.addEventListener("load", Vegleges)

function Vegleges(){
    for (let i = 0; i < langosjson.length; i++){
        let langos = langosjson[i]
        langosnevek.push(langos.nev)

        if (langos.so == null && langos.fokhagyma != null){
            langosok[3].innerHTML += `${langos.nev}: ${langos.fokhagyma}<br>`

        } else if (langos.fokhagyma == null && langos.so != null){
            langosok[3].innerHTML += `${langos.nev}: ${langos.so}<br>`

        } else if (langos.fokhagyma != null && langos.so != null){
            langosok[3].innerHTML += `${langos.nev}: ${langos.so}, ${langos.fokhagyma}<br>`

        } else if (!langos.so && !langos.fokhagyma){
            langosok[3].innerHTML += `${langos.nev}, Nem kérem<br>`

        }

        langosok[5].innerHTML += `${langos.nev}: ${langos.darab};<br>`
        osszesen += langos.ar * langos.darab
    }

    langosok[1].innerHTML = langosnevek.join(", ")
    langosok[7].innerHTML = `${osszesen} Ft`
}

button.addEventListener("click", Rendeles)

function Rendeles(){
    alert("Köszönjük a rendelést! Hamarosan kiszállítjuk önhöz!")
}